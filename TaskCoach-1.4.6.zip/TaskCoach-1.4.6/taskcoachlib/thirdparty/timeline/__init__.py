''' Timeline widget for wxPython '''

